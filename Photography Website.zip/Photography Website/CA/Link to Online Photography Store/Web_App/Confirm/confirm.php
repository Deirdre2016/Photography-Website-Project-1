<?php # register.php
// This script performs an INSERT query to add a record to the users table.

//include the header
//$page_title = 'Confirm Order';
include('includes/header.html');


 //call the DB connection php
if(isset($_COOKIE["total"])) { //Cookie is cleared when order is processed to stop duplicate order.
  require ('c:\wamp64\www\Photography Website\CA\Link to Online Photography Store\Web_App\mysqli_connect.php'); // Connect to the db.
  
  $u =  $_COOKIE["username"];
  $o =  $_COOKIE["total"];
  

	$q = "INSERT INTO orders (UserID, Username, OrderID, Product, Price, Quantity, Cost) VALUES ('1','dw13','1','(Ref 101)- Sunset over Claddagh, Galway, Price é40','40','1','40'))";		
	$r = @mysqli_query ($dbc, $q); // Run the query. Note: $dbc is set in the mysqli_connect.php script.
	
		
	//} else { // If it did not run OK.
		echo '<h1>System Error</h1>
		<p class="error">You could not be registered due to a system error. Please view error message below and try again. We apologize for any inconvenience.</p>'; 
			
		// Debugging message:
		echo '<p class="error"><em>' . mysqli_error($dbc) . '</em><br /><br /></p>';
						
	
	//close database connection
  mysqli_close($dbc);
  include('includes/footer.html');
  exit();
}
else {//Message if no total cookie due to order been processed already.
   echo '<p class="error">You Order has already been processed. Please do not refresh this page. Use the links above to navigate to a new page or logout. Thank you.</p>';
}
include('includes/footer.html');
exit();
?>
