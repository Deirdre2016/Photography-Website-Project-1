-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2017 at 02:37 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web_apps`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) UNSIGNED ZEROFILL NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` char(40) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `firstname`, `lastname`, `username`, `password`) VALUES
(0000000035, 'emily', 'murphy', 'murphy11', 'f68ec41cde16f6b806d7b04c705766b7318fbb1d'),
(0000000034, 'mary', 'jones', 'jones14', '4c46bc790ffe655a1e65acfacf95da50cd4d3902'),
(0000000033, 'mary', 'murphy', 'murphy10', '024b01916e3eaec66a2c4b6fc587b1705f1a6fc8'),
(0000000032, 'duncan', 'goodyew', 'goodyew10', 'a8dbbfa41cec833f8dd42be4d1fa9a13142c85c2'),
(0000000031, 'richard', 'harvey', 'harvey10', '330ba60e243186e9fa258f9992d8766ea6e88bc1'),
(0000000030, 'michael', 'walsh', 'walsh10', '6d749e8a378a34cf19b4c02f7955f57fdba130a5'),
(0000000029, 'john', 'ross', 'ross10', 'edba955d0ea15fdef4f61726ef97e5af507430c0'),
(0000000028, 'anita', 'jones', 'jones10', 'a1d7584daaca4738d499ad7082886b01117275d8'),
(0000000027, 'fred', 'smith', 'smith10', '1119cfd37ee247357e034a08d844eea25f6fd20f'),
(0000000026, 'doris', 'day', 'day10', '2aa60a8ff7fcd473d321e0146afd9e26df395147'),
(0000000025, 'Bill', 'Gates', 'Gates10', 'e38ad214943daad1d64c102faec29de4afe9da3d'),
(0000000024, 'deirdre', 'weldon', 'dw10', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
